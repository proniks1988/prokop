import java.util.Scanner;
import java.awt.Point;

import static java.lang.Math.abs;
import static java.lang.Math.pow;



public class Main {



    public static void main(String[] args)
    {

        Triangle tк = new Triangle();
        System.out.print("\r\n\r\n\r\n");


        Choise cр = new Choise();
        System.out.print("\r\n\r\n\r\n");



        Line l = new Line();
        System.out.print("\r\n\r\n\r\n");



        Brick b = new Brick();
        System.out.print("\r\n\r\n\r\n");


        Last last = new Last();
        System.out.print("\r\n\r\n\r\n");




	// write your code here
    }
}


class Triangle
{


    public Triangle()
    {
        game();
    }

    private void game()
    {
        int x = 0, y = 0;
        System.out.println("Введите два угла треугольника в грудусах");
        x = write("Введите угол АЛЬФА = ");
        y = write("Введите угол ВЕТА = ");


        if((x + y) == 90)
            System.out.println("Это прямоугольный треугольник.");
        else if( (x + y) < 180 )
            System.out.println("Такой треугольник существует!");
        else System.out.println("Такого треугольника не существует.");
    }


    private int write(String str)
    {
        int d = 0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextInt())
            {
                d = scan.nextInt();
                if(d < 0) continue;
                break;
            }
            else scan.nextLine();
        }
        return d;
    }
}


class Choise
{


    public Choise()
    {
        game();
    }

    private void game()
    {
        Double x = 0.0, y = 0.0, a = 0.0, b = 0.0, c = 0.0, d = 0.0;
        System.out.println("max{min{a, b}, min{c, d}}");
        a = write("Введите a = ");
        b = write("Введите b = ");
        c = write("Введите c = ");
        d = write("Введите d = ");

        if(a > b) x = b;
        else x = a;
        if(c > d) y = d;
        else y = c;
        if(x > y) a = x;
        else a = y;
        System.out.println("Ответ " + a);

    }


    private Double write(String str)
    {
        Double d = 0.0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextDouble())
            {
                d = scan.nextDouble();
                break;
            }
            else scan.nextLine();
        }
        return d;
    }
}


class Line
{


    public Line()
    {
        game();
    }

    private void game()
    {
        Point a, b, c;
        System.out.println("Определить лежат ли три точки на одной прямой");
        System.out.println("Введите координаты точки А:");
        a = new Point(write("Введите x1 = "), write("Введите y1 = "));
        System.out.println("Введите координаты точки B:");
        b = new Point(write("Введите x2 = "), write("Введите y2 = "));
        System.out.println("Введите координаты точки C:");
        c = new Point(write("Введите x3 = "), write("Введите y3 = "));



        if(a.x == b.x && a.x == c.x)
            System.out.println("Все три точки лежат на одной вертикальной прямой");
        else if(a.x == b.x || a.x == c.x)
            System.out.println("Будет деление на ноль, три точки НЕ лежат на одной прямой");
        else {
                double x = abs((double) (a.y - b.y)) / abs((double) (a.x - b.x));
                double y = abs((double) (a.y - c.y)) / abs((double) (a.x - c.x));
                if(x == y)
                    System.out.println("Все три точки лежат на одной прямой");
                else System.out.println("Три точки НЕ лежат на одной прямой");
        }




    }


    private int write(String str)
    {
        int d = 0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextInt())
            {
                d = scan.nextInt();
                if(d < 0) continue;
                break;
            }
            else scan.nextLine();
        }
        return d;
    }
}


class Brick
{

    public Brick(){game();}

    private void game()
    {
        Double width = 0.0, height = 0.0, a = 0.0, b = 0.0, c = 0.0;
        System.out.println("Введите размеры отверстия:");
        width = write("Введите ширину отверстия = ");
        height = write("Введите высоту отверстия = ");
        System.out.println("\r\nВведите размеры кирпича:");
        a = write("Введите длину кирпича = ");
        b = write("Введите ширину кирпича = ");
        c = write("Введите высоту кирпича = ");

        boolean state = false;

        if((width >= a && height >= b) || (width >= b && height >= a) || (width >= a && height >= c) ||
                (width >= c && height >= a) || (width >= b && height >= c) || (width >= c && height >= b)) state = true;

        System.out.println("Ответ " + (state? "Кирпичь проходит в отверстие" : "Кирпичь НЕ проходит в отверстие"));

    }


    private Double write(String str)
    {
        Double d = 0.0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextDouble())
            {
                d = scan.nextDouble();
                if(d <= 0) continue;
                break;
            }
            else scan.nextLine();
        }
        return d;
    }
}


class Last
{

    private double x;
    private double y;

    public Last()
    {

        System.out.println("Вычислить значение функции\r\nif(x > 3) y = 1 / (x*x*x + 6)\r\nif(x <= 3) y = x*x - 3*x + 9");

        write("Введите х = ");
        game();
        System.out.println("Ответ: y = " + y);
    }

    private void game()
    {

        if(x > 3)
            y = 1 / (pow(x, 3) + 6);
        else
            y = pow(x, 2) - 3 * x  + 9;

    }


    private void write(String str)
    {
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextDouble())
            {
                x = scan.nextDouble();
                break;
            }
            else scan.nextLine();
        }
    }

}
