
import java.lang.annotation.Annotation;
import java.math.BigInteger;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import static java.lang.Math.abs;
import static java.lang.Math.pow;


public class Main {

    public static void main(String[] args)
    {

        One one = new One();
        System.out.print("\r\n\r\n\r\n");

        Two two = new Two();
        System.out.print("\r\n\r\n\r\n");

        Four f = new Four();
        f.getSum();
        System.out.print("\r\n");
        f.getMul();
        System.out.print("\r\n\r\n\r\n");


        Five five = new Five();
        System.out.print("\r\n\r\n\r\n");


        Seven s = new Seven();
        System.out.print("\r\n\r\n\r\n");

        Eight eight = new Eight();
        System.out.print("\r\n\r\n\r\n");


        //Six six = new Six();
        

        

	// write your code here
    }
}


class One
{
    public One()
    {
        game();
    }

    private void game()
    {
        int n = write("Введите любое натуральное положительное число ");
        int sum = 0;
        for(int i = 0; i <= n; i++)
            sum += i;
        System.out.print("Ответ сумма чисел равна от 0 до " + n + " = " + sum);
    }


    private int write(String str)
    {
        int d = 0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextInt())
            {
                d = scan.nextInt();
                if(d < 0) continue;
                break;
            }
            else scan.nextLine();
        }
        return d;
    }
}


class Two
{
    private int st;
    private int fin;
    private int h;

    public Two()
    {
        game();
    }

    private void game()
    {
        System.out.print("Вычислить значение функции в интервале [a,b]:\r\nif(x > 2) y = x\r\nif(x <= 2) y = -x\r\n");
        int x, y;
        x = write("Введите начало отрезка = ");
        y = write("Введите конец отрезка = ");
        if(x < y) {st = x; fin = y;}
        else {st = y; fin = x;}
        h = abs(write("Введите шаг = "));

        int tmp;
        for(int i = st; i <= fin; i += h)
        {
            if(i > 2) tmp = i;
            else tmp = -i;
            System.out.print(tmp + " ");
        }
    }


    private int write(String str)
    {
        int d = 0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextInt())
            {
                d = scan.nextInt();
                break;
            }
            else scan.nextLine();
        }
        return d;
    }
}


class Four
{

    public void  getSum()
    {
        long sum = 0;
        for(int i = 1; i <= 100; i++)
            sum += i*i;
        System.out.println("Cумма квадратов первых 100 чисел равна " + sum);
    }

    public void  getMul()
    {
        BigInteger bi = new BigInteger("1");
        for(int i = 1; i <= 200; i++)
            bi = bi.multiply(new BigInteger(new Integer(i*i).toString()));
        System.out.println("Произведение квадратов первых 200 чисел равна " + bi);

    }

}


class Five
{
    public Five()
    {
        game();
    }

    private void game()
    {
        System.out.print("Найти сумму членов ряда, модуль которых больше или равен заданому числу\r\n");
        Double e = abs(write("Введите любое число "));
        Double tmp = 0.0, sum = 0.0;
        int n = 0;
        while(true)
        {
            tmp = 1/pow(2, n) + 1/pow(3, n);
            if(tmp < e) break;
            sum += tmp;
            n++;
        }
        System.out.print("Ответ сумма чисел равна " + sum);
    }


    private Double write(String str)
    {
        Double d = 0.0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextDouble())
            {
                d = scan.nextDouble();
                break;
            }
            else scan.nextLine();
        }
        return d;
    }


}


class Six
{

    public Six()
    {
        for(int i = 0; i < 256; i++)
            System.out.print(i + " = " + (char)i + "\r\n");

    }


}

class Seven
{

    private int m;
    private int n;


    public Seven()
    {
        game();
    }


    private void game()
    {
        System.out.print("Для каждого натурального числа отрезка [m, n], найти все делители кроме единицы и самого числа:\r\n");
        int x, y;
        x = write("Введите начало отрезка = ");
        y = write("Введите конец отрезка = ");
        if(x < y) {m = x; n = y;}
        else {m = y; n = x;}

        for(int i = m; i <= n; i++)
        {
            System.out.print("Тестируемое число = " + i + "; Делители: ");
            for(int j = 0; j <= n; j++)
            {
                if(j != 0 && j != 1 && i != j && (i%j) == 0)
                    System.out.print(j + " ");
            }
            System.out.print("\r\n");
        }
    }


    private int write(String str)
    {
        int d = 0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextInt())
            {
                d = scan.nextInt();
                break;
            }
            else scan.nextLine();
        }
        return d;
    }

}


class Eight
{

    private BigInteger one;
    private BigInteger two;

    public Eight()
    {
        game();
    }


    private void game()
    {
        System.out.print("Определить цифры которые входят в первое и второе число:\r\n");
        TreeSet<Character> arr = new TreeSet<Character>();

        one = new BigInteger((write("Введите первое натуральное число ")).toString());
        two = new BigInteger((write("Введите второе натуральное число ")).toString());

        for(var v : one.toString().toCharArray()) {
            for (var x : two.toString().toCharArray()){
                if (v == x) arr.add(x);
            }
        }
        System.out.print("Повторки: ");
        for(var v : arr)
            System.out.print(v + " ");
        System.out.println();

    }


    private BigInteger write(String str)
    {
        BigInteger d;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(str);
            if(scan.hasNextBigInteger())
            {
                d = scan.nextBigInteger();
                break;
            }
            else scan.nextLine();
        }
        return d;
    }


}