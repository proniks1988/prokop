import javafx.geometry.Point2D;
import javafx.scene.shape.Ellipse;

import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.io.IOException;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;




import static java.lang.Math.sqrt;
import static java.lang.Math.pow;
import static java.lang.Math.PI;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.tan;


public class Main  {

    public static void main(String[] args) {

        equation ob = new equation();

        ob.one();
        System.out.print("\r\n\r\n\r\n");

        ob.two();
        System.out.print("\r\n\r\n\r\n");

        ob.three();
       System.out.print("\r\n\r\n\r\n");

        ob.four();
        System.out.print("\r\n\r\n\r\n");


        ConvertTime ct = new ConvertTime();
        System.out.println(ct);
        System.out.print("\r\n\r\n\r\n");



        Scope s = new Scope();
        s.game();



    }


}


class equation
{
    public void one()
    {
        double a = 0.0, b = 0.0, c = 0.0, z = 0.0;
        System.out.println("z = ((a - 3) * b / 2) + c");
        a = qust("a");
        b = qust("b");
        c = qust("c");
        z = ((a - 3) * b / 2) + c;
        System.out.println("z = " + z);

    }


    public void two()
    {
        double a = 0.0, b = 0.0, c = 0.0, z = 0.0;
        System.out.println("z = ((b + sqrt(b*b + 4*a*c))/2*a)-a*a*a*c + 1/(b*b)");
        a = qust("a");
        b = qust("b");
        c = qust("c");
        if(a == 0 || b == 0)
            throw new ArithmeticException("деление на ноль запрещено");
        else if((pow(b, 2) + 4*a*c) < 0)
            throw new ArithmeticException("выражение под корнем долно быть положительным");
        else
            z = ((b + sqrt(pow(b, 2) + 4*a*c))/2*a) - pow(a, 3)*c + 1/pow(b, 2);
        System.out.println("z = " + z);

    }


    public void three()
    {
        double x = 0.0, y = 0.0, z = 0.0;
        System.out.println("z = (sin(x) + cos(y)) / (cos(x) - sin(y)) + tg(x*y)");
        System.out.println("Введите х и у в градусах");
        x = qust("x");
        y = qust("y");
        if(cos(x*PI/180) == sin(y*PI/180))
            throw new ArithmeticException("деление на ноль запрещено");
        else if(cos(x*y*pow(PI/180, 2)) == 0)
            throw new ArithmeticException("тангенс угла n*PI/2 не существует");
        else
            z = (sin(x*PI/180) + cos(y*PI/180)) / (cos(x*PI/180) - sin(y*PI/180)) + tan(x*y*pow(PI/180, 2));
        System.out.println("z = " + z);
    }


    public void four()
    {
        System.out.println("Введите чмсло формата ххх.ууу");
        double x = 0.0, y = 0.0;
        x = qust("число типа double");
        String str = Double.toString(x);
        for(int i = 0; i<str.length(); i++)
        {
            if(str.charAt(i) == '.')
            {
                char[] arr = new char[256];
                if((i+1) != str.length())
                {
                    str.getChars((i + 1), str.length(), arr, 0);
                    arr[(str.length() - i - 1)] = '.';
                    str.getChars(0, (i+1), arr, (str.length() - i));
                    arr[str.length()] = '\0';
                    y = new Double(String.valueOf(arr));
                }
                break;
            }
        }
        System.out.println("\nчисло перевертышь = " + y);
    }



    private static double qust(String ch)
    {
        double d = 0.0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print("Введите " + ch + " = ");
            if (scan.hasNextDouble()) {
                d = scan.nextDouble();
                break;
            } else scan.next();

        }
        //scan.close();
        return d;
    }

}




class ConvertTime
{
    private long hours;
    private long minutes;
    private long seconds;
    private long number;


    public ConvertTime()
    {
        game();
    }


    public void game()
    {
        long d = write("Введите натуральное положительное число (перевод время) = ");
        number = d;
        hours = d/3600;
        minutes = (d - hours*3600) / 60;
        seconds = (d - ( hours*3600 + minutes*60));
    }


    private static long write(String ch)
    {
        long d = 0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print(ch);
            if (scan.hasNextLong()) {
                d = scan.nextLong();
                if(d < 0) continue;
                break;
            } else scan.next();

        }
        return d;
    }


    @Override
    public String toString()
    {
        String tmp = "" + hours + "ч " +  minutes + "мин " + seconds + "сек";
        return tmp;
    }




}






class Scope
{
    Vector<MyShape> scope;

    public Scope()
    {
        scope = new Vector<MyShape>();
        scope.add(new Ellipses(0, -1, 0.5, 0.75));
        scope.add(new Rect(-2, 0, 4, 4));
        scope.add(new Rect(-4, -3, 8, 3));
    }


    public void game()
    {
        while(true)
        {
            System.out.println("Для выхода из цикла укажите координаты точки -100 и -100\r\n");
            Point2D p = new Point2D(qust("point.x"), qust("point.y"));
            boolean state = false;
            for(Object el : scope)
            {
                if(state) break;
                else if((el.getClass().getName()).equals(Rect.class.getName()))
                    state = ((Rect)el).contain(p.getX(), p.getY())? true : false;
                else if((el.getClass().getName()).equals(Ellipses.class.getName()))
                {
                    if(((Ellipses)el).contain(p.getX(), p.getY()))
                        break;
                }
            }
            System.out.println("\r\n" + state + "\r\n");
            if(p.equals(new Point2D(-100.0,-100.0))) break;
        }
    }


    private double qust(String ch)
    {
        double d = 0.0;
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            System.out.print("Введите " + ch + " = ");
            if (scan.hasNextDouble()) {
                d = scan.nextDouble();
                break;
            } else scan.next();

        }
        //scan.close();
        return d;
    }


}

abstract class MyShape
{
    public abstract boolean contain(double x, double y);
}
class Rect extends MyShape
{
    private double x;
    private double y;
    private double width;
    private double height;
    public Rect(double x, double y, double width, double height)
    {
        this.x = x;
        this.y =y;
        this.width = width;
        this.height = height;
    }

    @Override
    public  boolean contain(double X, double Y)
    {
        boolean state = ((X >= x && X <= (x + width)) && (Y >= y && Y <= (y + height)))?  true :  false;
        return state;
    }
}
class Ellipses extends MyShape
{
    private double x;
    private double y;
    private double RX;
    private double RY;
    public Ellipses(double x, double y, double RX, double RY)
    {
        this.x = x;
        this.y = y;
        this.RX = RX;
        this.RY = RY;
    }
    @Override
    public boolean contain(double X, double Y)
    {
        boolean state = false;
        if(X >=(x-RX) && X <= (x+RX))
        {
            double tmp = 0.0;
            if(RX != 0)
                tmp = sqrt(1 - pow(X, 2)/pow(RX, 2))*pow(RY, 2);
            if(Y >=(y-tmp) && Y <= (y+tmp))
                state = true;
        }
        return state;
    }
}


